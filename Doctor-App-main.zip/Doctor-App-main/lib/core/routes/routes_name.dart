class RoutesName {
  static const String FisrtScreen = '/';
  static const String SignIn = '/SignIn';
  static const String Home = '/Home';
   static const String SingleDoctor = '/SingleDoctor';
   static const String Doctors = '/Doctors';
   static const String Profile = '/Profile';
   static const String Setiings = '/Setiings';
}

