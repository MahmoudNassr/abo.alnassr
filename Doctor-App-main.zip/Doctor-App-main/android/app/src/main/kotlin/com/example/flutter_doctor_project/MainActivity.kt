package com.example.flutter_doctor_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
